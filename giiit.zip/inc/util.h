#ifndef TJU_TCP_SRC_UTIL_H_
#define TJU_TCP_SRC_UTIL_H_

double min(double a, double b);
double max(double a, double b);

#endif //TJU_TCP_SRC_UTIL_H_

